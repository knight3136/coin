
ccminer for OS X

***************************************************************
   LTC donation address: LdfQP6iPma4kVoUbcPx356ZQyGnHfE6qek
   BTC donation address: 19NbeTWX7pvvSHSnaM9Qze7JD4fBPfpbNT
***************************************************************

>>> Introduction <<<

ccminer for OSX is the Mac OS X compiled version of 
ccminer by Christian Buchner.  See 
https://bitcointalk.org/index.php?topic=167229.0 for more 
details about ccminer.

>>> Requirements <<<

OS X 10.9 Mavericks

NVIDIA CUDA 6.0 Toolkit & Drivers: 
https://developer.nvidia.com/cuda-downloads

Compute 2.x or Higher NVIDIA GPU, Compute 1.x GPUs are not 
supported by the 5.5 CUDA Toolkit. See
https://developer.nvidia.com/cuda-gpus to lookup your GPU.

>>> Instructions <<<

See the README (ccminer).txt file for command-line syntax for 
ccminer.
